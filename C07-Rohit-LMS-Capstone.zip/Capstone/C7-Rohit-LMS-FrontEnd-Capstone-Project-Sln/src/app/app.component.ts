import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'C1-Rohit-TRMS-C7-FrontEnd-Project-Sln';
}
