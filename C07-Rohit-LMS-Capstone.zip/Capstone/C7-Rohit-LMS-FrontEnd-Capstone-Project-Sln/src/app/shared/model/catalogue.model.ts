export interface Catalogue{
    id:string;
    title: string;
    author:string;
    genre: string;
    isbn: string;
    availability: string;
}