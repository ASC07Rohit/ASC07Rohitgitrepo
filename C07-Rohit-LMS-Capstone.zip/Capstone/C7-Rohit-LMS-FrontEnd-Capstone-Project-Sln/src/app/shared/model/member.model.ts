export interface Member {
  id: string;
  name: string;
  contactNumber: string;
  email: string;
  memberShipType: string;
  registrationDate: string;
}
