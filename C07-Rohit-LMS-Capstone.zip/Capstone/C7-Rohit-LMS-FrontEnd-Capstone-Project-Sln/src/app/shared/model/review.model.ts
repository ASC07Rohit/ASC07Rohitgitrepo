export interface Review {
    fullName: string;
    feedback: string;
  }
  