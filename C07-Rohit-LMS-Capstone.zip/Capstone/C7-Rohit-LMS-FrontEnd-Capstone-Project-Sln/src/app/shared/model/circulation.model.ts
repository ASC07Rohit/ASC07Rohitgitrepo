export interface Circulation{
    id:string;
    memberId: string;
    catalogueId: string;
    borrowDate: string;
    returnDate:string;
}