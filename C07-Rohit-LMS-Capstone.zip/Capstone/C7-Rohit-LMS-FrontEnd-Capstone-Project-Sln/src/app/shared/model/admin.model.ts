export interface Admin{
    id: string;
    fullName: string;
    mobileNumber: string;
    email: string;
    password: string;
}